/** * Copyright (c) 2009-2015 Social Vision GmbH. All rights reserved. */
package com.ni3.ag.adminconsole.client.view.useradmin;

import javax.swing.JPanel;

public class MapPanel extends JPanel{

}
