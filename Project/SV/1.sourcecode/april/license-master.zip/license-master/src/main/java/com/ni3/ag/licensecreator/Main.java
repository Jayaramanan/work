package com.ni3.ag.licensecreator;

import com.ni3.ag.licensecreator.gui.LicenseCreator;

public class Main{
	public static void main(String[] args){
		new LicenseCreator().setVisible(true);
	}
}
