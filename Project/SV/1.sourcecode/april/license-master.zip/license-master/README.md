# license
licenses generator for Navigator and Admin Console
