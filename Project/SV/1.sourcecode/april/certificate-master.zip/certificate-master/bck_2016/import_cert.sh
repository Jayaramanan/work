keytool -import -trustcacerts -alias server -file social_vision_gmbh.p7b -keystore SocialVisionGmbH.jks
