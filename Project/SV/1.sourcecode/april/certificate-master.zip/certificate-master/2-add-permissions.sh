jar -vumf manifest Ni3.jar
