jarsigner -verify -verbose -certs Ni3.jar | grep verified
