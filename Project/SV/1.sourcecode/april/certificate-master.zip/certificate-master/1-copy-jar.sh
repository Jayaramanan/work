cp -f ../github_navigator/ni3/target/Ni3_orig.jar ./Ni3.jar
