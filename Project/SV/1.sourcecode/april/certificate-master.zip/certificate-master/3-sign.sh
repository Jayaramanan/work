jarsigner -tsa http://timestamp.digicert.com -keystore prod_social-vision_ch.jks -storepass KnLBS84i Ni3.jar server
